/***************************************************************************//**
 * @file
 * @brief Routines for the Relay Control Client plugin.
 *******************************************************************************
 * # License
 * <b>Copyright 2018 Silicon Laboratories Inc. www.silabs.com</b>
 *******************************************************************************
 *
 * The licensor of this software is Silicon Laboratories Inc. Your use of this
 * software is governed by the terms of Silicon Labs Master Software License
 * Agreement (MSLA) available at
 * www.silabs.com/about-us/legal/master-software-license-agreement. This
 * software is distributed to you in Source Code format and is governed by the
 * sections of the MSLA applicable to Source Code.
 *
 ******************************************************************************/

// this file contains all the common includes for clusters in the util
#include "app/framework/include/af.h"
#include "app/framework/plugin/relay-control-client/relay-control-client.h"

bool emberAfRelayControlClusterGetRelayStateResponseCallback(bool isEnabled)
{
  emberAfRelayControlClusterPrintln("Relay: %p", (isEnabled ? "on" : "off"));

  emberAfSendImmediateDefaultResponse(EMBER_ZCL_STATUS_SUCCESS);
  return true;
}

void emberAfPluginRelayControlClientSendSetRelayState(EmberNodeId nodeId,
                                                      uint8_t srcEndpoint,
                                                      uint8_t dstEndpoint,
                                                      bool isEnabled,
                                                      uint32_t magicNumber)
{
  EmberStatus status;
  emberAfFillCommandRelayControlClusterSetRelayState(isEnabled,
                                                     magicNumber);
  emberAfSetCommandEndpoints(srcEndpoint, dstEndpoint);
  status = emberAfSendCommandUnicast(EMBER_OUTGOING_DIRECT, nodeId);
  if (status != EMBER_SUCCESS) {
    emberAfRelayControlClusterPrintln("Error in send set relay state %x", status);
  }
}
